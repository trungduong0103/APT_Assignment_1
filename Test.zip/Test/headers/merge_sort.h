#ifndef APT_ASSIGNMENT_1_MERGE_SORT_H
#define APT_ASSIGNMENT_1_MERGE_SORT_H

void merge(double arr[], unsigned int l, unsigned int m, unsigned int r);

void merge_sort(double arr[], unsigned int l, unsigned int r);

#endif //APT_ASSIGNMENT_1_MERGE_SORT_H
